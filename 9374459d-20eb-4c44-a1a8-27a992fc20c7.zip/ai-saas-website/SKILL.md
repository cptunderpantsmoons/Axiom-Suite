---
name: ai-saas-website
description: >
  Framework-agnostic skeleton and pattern reference for building a production-grade
  AI SaaS platform. Covers auth, Stripe subscriptions, a streaming LLM playground,
  Firestore data schema, tier gating, rate limiting, security headers, and a full
  QA + security audit checklist. Code examples use Next.js as a reference
  implementation — adapt patterns to any framework (Nuxt, SvelteKit, Remix, Laravel,
  etc.). Use this skill whenever a developer wants architecture guidance, patterns,
  or a checklist for building an AI SaaS product without being locked into a specific
  stack. For a fully automated, zero-config Next.js + Firebase build, use the
  `ai-saas-website-pro` skill instead.
_agensi: "55555d4f-ce49-423d-abc0-726a62c070f1"
---

# AI SaaS Website — Skeleton & Pattern Reference

A framework-agnostic playbook of **architecture patterns, data schemas, and a QA
checklist** for building a production-grade AI SaaS platform. Firebase, Stripe, and
a streaming LLM playground are covered as concrete examples — bring your own framework.

> **How to read this skill**
>
> All code examples are **Next.js 16 reference implementations**. They show the
> pattern — session cookies, SSE streaming, webhook verification, tier gating —
> in a concrete, runnable form. If you are using a different framework, read the
> example for the *concept*, then implement the equivalent in your stack.
>
> Looking for a fully automated, zero-manual-steps build on Next.js + Firebase?
> Use the **`ai-saas-website-pro`** skill instead.

---

## 0. Intake — Ask Before Building

**Before writing a single file or running any command**, collect the following from the user. Do not assume defaults. Ask all three questions in one message.

---

### Question 1 — Brand

> **What is your brand name, and what colors or vibe describes it?**
> (e.g. "Acme AI — dark navy, gold accent, professional" or "Luma — light mode, soft violet, friendly")

Use the answer to:
- Set `--primary`, `--accent`, and base `--background` HSL tokens in `globals.css`
- Populate all `APP_NAME`, `<title>`, JSON-LD, and OG meta fields
- Name the project directory, `package.json` `name`, and `apphosting.yaml` site ID

---

### Question 2 — Features

> **Which features would you like included?**
> Select any combination:

| # | Feature | What it includes |
|---|---------|-----------------|
| 1 | **Auth** *(always on)* | Email/password + Google OAuth, session cookie, auth guard, middleware redirects |
| 2 | **Landing Page** | Hero, features grid, how-it-works, CTA banner, partner marquee, footer |
| 3 | **Pricing & Subscriptions** | Stripe Checkout, webhook, free/pro/dev tier gating |
| 4 | **LLM Playground** | Multi-model streaming workspace, column layout, prompt bar, metrics display |
| 5 | **Dashboard** | Usage stats, subscription status, account settings |
| 6 | **Admin Panel** | User list, usage overview, custom claim gate |
| 7 | **Community / Blog** | Public posts listing, individual post pages |
| 8 | **Onboarding Flow** | Post-signup wizard to capture user intent |
| 9 | **Email Notifications** | Nodemailer SMTP — new user alert, welcome email |
| 10 | **SEO & Deployment** | robots.ts, sitemap.ts, JSON-LD, `apphosting.yaml`, Firebase secrets |

> Default if no answer: features 1, 2, 3, 4, 5, 10.

Only scaffold, wire up, and reference code for features the user selects. Skip everything else entirely — no placeholder files, no commented-out imports.

---

### Question 3 — Brand Assets

> **Do you have a logo or icon pack you'd like to use?**
> Please attach or paste the file path(s) for any of the following:
>
> - **Logo** (SVG preferred) — used in the header, footer, and OG image
> - **Favicon / app icon** (PNG, ICO, or SVG) — placed at `public/icon.png` and `public/favicon.ico`
> - **Icon pack** (e.g. a custom SVG sprite, Phosphor, or Heroicons subset) — used throughout the UI instead of Lucide React
> - **OG / social image** (1200×630 PNG) — used for `openGraph.images` in metadata

**Never install or import Spline (`@splinetool/react-spline`), Three.js, Babylon.js, or any other 3-D runtime** for the hero or any other section. These add megabytes to the bundle and require assets not yet in scope. Use the hero placeholder pattern described in Section 12 instead.

If no assets are provided:
- Use **Lucide React** for all icons (already in the install list)
- Generate a simple text-based SVG logo using the brand name and primary color
- Leave favicon as the Next.js default until assets are supplied

---

Once all three answers are collected, proceed to **Section 1** and build only what was requested.

---

## 1. Tech Stack

| Layer | Choice | Rationale |
|-------|--------|-----------|
| Framework | Next.js 16 App Router | RSC + streaming, edge-compatible |
| Language | TypeScript (strict) | Catch errors at build time |
| Styling | TailwindCSS v4 (CSS-native config) | No PostCSS config file needed |
| UI Components | shadcn/ui (Radix primitives) | Accessible, unstyled |
| Icons | Lucide React | Consistent, tree-shaken |
| Animation | Framer Motion | Declarative, performant |
| Auth | Firebase Auth (email/password + Google OAuth) | Managed, scales to zero |
| Database | Cloud Firestore | Real-time, serverless |
| Payments | Stripe Checkout + webhooks | Industry standard |
| Deployment | Firebase App Hosting | Git-integrated, auto-scales |
| Security middleware | CybrShield (custom) | Bot/scanner blocking, IP denylist, CSP nonces |

---

## 2. Project Scaffold

Scaffold using your framework's standard CLI. The directory structure and patterns
in this skill are framework-agnostic — adapt paths and config conventions to your stack.

> **Next.js Quickstart** (see Appendix A for the full command)
>
> ```bash
> npx create-next-app@latest ./ \
>   --typescript --tailwind --eslint --app --src-dir \
>   --import-alias "@/*" --no-turbopack
> ```
>
> For other frameworks: Nuxt (`nuxi init`), SvelteKit (`npm create svelte`),
> Remix (`npx create-remix`). The dependency list in Appendix A covers the
> Firebase, Stripe, and UI packages regardless of framework.

---

## 3. Directory Structure

```
src/
├── app/
│   ├── layout.tsx                # Root layout (fonts, providers, JSON-LD)
│   ├── page.tsx                  # Marketing landing page
│   ├── globals.css               # TailwindCSS v4 @theme tokens
│   ├── robots.ts
│   ├── sitemap.ts
│   ├── login/page.tsx
│   ├── register/page.tsx
│   ├── onboarding/page.tsx
│   ├── dashboard/page.tsx
│   ├── playground/page.tsx       # Streaming LLM workspace
│   ├── subscriptions/page.tsx
│   ├── admin/page.tsx
│   ├── privacy/page.tsx
│   ├── terms/page.tsx
│   └── api/
│       ├── session/route.ts      # Set/clear Firebase session cookie
│       ├── stripe/
│       │   ├── checkout/route.ts
│       │   └── webhook/route.ts
│       ├── playground/
│       │   ├── stream/[modelId]/route.ts
│       │   └── quota/route.ts
│       ├── admin/users/route.ts
│       ├── health/route.ts
│       └── notify-new-user/route.ts
│
├── components/
│   ├── ui/                       # shadcn/ui primitives
│   ├── auth-guard.tsx
│   ├── header.tsx
│   ├── footer.tsx
│   ├── pricing-section.tsx
│   ├── cookie-consent.tsx
│   ├── theme-provider.tsx
│   └── playground/
│       ├── column-card.tsx
│       ├── model-selector.tsx
│       ├── prompt-bar.tsx
│       └── response-stream.tsx
│
├── firebase/
│   ├── config.ts
│   ├── client-provider.tsx
│   ├── provider.tsx
│   └── firestore/
│       ├── users.ts
│       └── subscriptions.ts
│
├── lib/
│   ├── env.ts                    # Validated env getters (throws on missing)
│   ├── firebase-admin.ts         # Admin SDK singleton (server-only)
│   ├── stripe.ts
│   ├── session-verifier.ts
│   ├── rate-limit.ts
│   ├── csp.ts
│   ├── log.ts
│   └── playground/
│       ├── types.ts
│       ├── providers/
│       │   ├── index.ts          # Model registry + router
│       │   └── openai-compatible.ts
│       ├── sse.ts
│       ├── tier-config.ts
│       └── guards.ts
│
├── hooks/
│   ├── use-toast.ts
│   └── use-auth.ts
│
└── proxy.ts                      # Next.js 16 middleware (was middleware.ts)
```

---

## 4. Environment Variables

### `.env.example` (commit this file)

```bash
# ── Firebase client (NEXT_PUBLIC_* -> browser bundle) ─────────────────────────
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_SITE_URL=https://your-domain.com
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=

# ── Server-only secrets (never NEXT_PUBLIC_) ──────────────────────────────────
GOOGLE_APPLICATION_CREDENTIALS_JSON=   # Service account JSON, stringified
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_PRO_PLAN_ID=
STRIPE_DEV_PLAN_ID=

# SMTP (optional — feature-gated; no-op if unset)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASSWORD=
ADMIN_EMAIL=

# ── LLM Gateway ───────────────────────────────────────────────────────────────
# Use a unified OpenAI-compatible gateway so one key covers multiple providers.
LLM_GATEWAY_BASE_URL=https://api.openai.com/v1
LLM_GATEWAY_API_KEY=

# Direct Google AI (Gemini) — fallback model
GOOGLE_AI_API_KEY=

# Local Ollama (optional)
OLLAMA_BASE_URL=http://localhost:11434
```

### `src/lib/env.ts` pattern

```typescript
import 'server-only';

function require(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`[env] Missing required env var: ${key}`);
  return val;
}

export const serverEnv = {
  get STRIPE_SECRET_KEY()      { return require('STRIPE_SECRET_KEY'); },
  get STRIPE_WEBHOOK_SECRET()  { return require('STRIPE_WEBHOOK_SECRET'); },
  get LLM_GATEWAY_API_KEY()    { return require('LLM_GATEWAY_API_KEY'); },
  get LLM_GATEWAY_BASE_URL()   { return require('LLM_GATEWAY_BASE_URL'); },
  get GOOGLE_AI_API_KEY()      { return require('GOOGLE_AI_API_KEY'); },
  get GOOGLE_APPLICATION_CREDENTIALS_JSON() {
    return require('GOOGLE_APPLICATION_CREDENTIALS_JSON');
  },
  // Optional — null instead of throwing
  get SMTP_USER()      { return process.env.SMTP_USER ?? null; },
  get SMTP_PASSWORD()  { return process.env.SMTP_PASSWORD ?? null; },
  get OLLAMA_BASE_URL() {
    return process.env.OLLAMA_BASE_URL ?? 'http://localhost:11434';
  },
};
```

**Rule:** Never read `process.env` directly in route handlers. Always use `serverEnv.*`.

---

## 5. Firebase Setup

### 5.1 Client config (`src/firebase/config.ts`)

```typescript
import { initializeApp, getApps, getApp } from 'firebase/app';

const firebaseConfig = {
  apiKey:            process.env.NEXT_PUBLIC_FIREBASE_API_KEY!,
  authDomain:        process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN!,
  projectId:         process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID!,
  storageBucket:     process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET!,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID!,
  appId:             process.env.NEXT_PUBLIC_FIREBASE_APP_ID!,
};

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
```

### 5.2 Admin SDK singleton (`src/lib/firebase-admin.ts`)

```typescript
import 'server-only';
import { initializeApp, getApps, cert, App } from 'firebase-admin/app';
import { getAuth }      from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { serverEnv }    from './env';

let adminApp: App;

function getAdminApp(): App {
  if (!adminApp) {
    const credential = JSON.parse(serverEnv.GOOGLE_APPLICATION_CREDENTIALS_JSON);
    adminApp = getApps().find(a => a.name === 'admin') ??
      initializeApp({ credential: cert(credential) }, 'admin');
  }
  return adminApp;
}

export const adminAuth = () => getAuth(getAdminApp());
export const adminDb   = () => getFirestore(getAdminApp());
```

### 5.3 Session cookie (`src/app/api/session/route.ts`)

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { adminAuth } from '@/lib/firebase-admin';
import { cookies }   from 'next/headers';

export async function POST(req: NextRequest) {
  const { idToken } = await req.json();
  const expiresIn   = 60 * 60 * 24 * 14 * 1000; // 14 days
  const sessionCookie = await adminAuth().createSessionCookie(idToken, { expiresIn });

  (await cookies()).set('__session', sessionCookie, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path:     '/',
    maxAge:   expiresIn / 1000,
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  (await cookies()).delete('__session');
  return NextResponse.json({ ok: true });
}
```

### 5.4 Firestore collection schema

```
/users/{uid}
  email, displayName, tier, stripeCustomerId,
  stripeSubscriptionId, createdAt, onboardingComplete

/subscriptions/{uid}
  planId, status, currentPeriodEnd

/usage/{uid}/playground/{date}
  tokensIn, tokensOut, requestCount
```

---

## 6. Auth Flow

### Client provider (`src/firebase/client-provider.tsx`)

```tsx
'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from './config';

type AuthCtx = { user: User | null; loading: boolean };
export const FirebaseContext = createContext<AuthCtx>({ user: null, loading: true });

export function FirebaseClientProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser]       = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const auth = getAuth(app);

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      if (u) {
        const idToken = await u.getIdToken();
        await fetch('/api/session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken }),
        });
      } else {
        await fetch('/api/session', { method: 'DELETE' });
      }
      setUser(u);
      setLoading(false);
    });
  }, [auth]);

  return (
    <FirebaseContext.Provider value={{ user, loading }}>
      {children}
    </FirebaseContext.Provider>
  );
}

export const useAuth = () => useContext(FirebaseContext);
```

### Auth guard (`src/components/auth-guard.tsx`)

```tsx
'use client';
import { useAuth }    from '@/firebase/client-provider';
import { useRouter }  from 'next/navigation';
import { useEffect }  from 'react';

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace('/login');
  }, [user, loading, router]);

  if (loading || !user) return null;
  return <>{children}</>;
}
```

### Session verifier (`src/lib/session-verifier.ts`)

```typescript
import 'server-only';
import { cookies }   from 'next/headers';
import { adminAuth } from './firebase-admin';

export async function verifySession() {
  const sessionCookie = (await cookies()).get('__session')?.value;
  if (!sessionCookie) return null;
  try {
    return await adminAuth().verifySessionCookie(sessionCookie, true);
  } catch {
    return null;
  }
}
```

---

## 7. Middleware (`src/proxy.ts`)

> **Next.js 16** renamed `middleware.ts` to `proxy.ts`. The export is `export default async function proxy(...)`, not the named `middleware` export.

The middleware pipeline runs in this order:
1. **Security check** (bot/scanner blocking, IP denylist) — if denied, return 403 immediately, no CSP needed.
2. **Admin route gate** (`/rag`, `/api/cybrshield/*`) — cryptographically verify the `__session` cookie via Web Crypto (Edge-compatible, no firebase-admin), then check admin allowlist. Deny by default.
3. **CSP nonce** — generate a fresh nonce per request, forward on request headers for `layout.tsx` to read, attach CSP to response.

```typescript
// src/proxy.ts (reference pattern)
import { NextResponse, type NextRequest } from 'next/server';
import { buildCsp, generateNonce } from '@/lib/csp';
import { verifySessionCookie } from '@/lib/session-verifier';
import { SESSION_COOKIE_NAME } from '@/lib/session-cookie';

function isAdminRoute(pathname: string): boolean {
  return pathname === '/rag' || pathname.startsWith('/rag/') ||
    pathname.startsWith('/api/admin/');
}

export default async function proxy(request: NextRequest): Promise<NextResponse> {
  // 1. Security layer — adapt to your threat model
  // if (isDenied) return new NextResponse('Forbidden', { status: 403 });

  const { pathname } = request.nextUrl;

  // 2. Admin gate
  if (isAdminRoute(pathname)) {
    const cookie = request.cookies.get(SESSION_COOKIE_NAME)?.value;
    const claims = cookie ? await verifySessionCookie(cookie) : null;
    const isAdmin = claims?.email_verified && claims?.role === 'admin';
    if (!isAdmin) return new NextResponse('Admin access required.', { status: 403 });
  }

  // 3. CSP nonce
  const nonce = generateNonce();
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-nonce', nonce);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set('Content-Security-Policy', buildCsp(nonce));
  return response;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|icon.png).*)'],
};
```

> **Key pattern**: The session verifier in `src/lib/session-verifier.ts` must be **Edge-compatible** — it cannot use `firebase-admin`. Instead, implement RS256 JWT verification using the Web Crypto API against Firebase's public JWKS endpoint (`https://www.googleapis.com/service_accounts/v1/metadata/jwk/firebase-adminsdk`). Cache the JWKS with a 1-hour TTL. The Admin SDK is only used in Node.js API routes.

---

## 8. Stripe Integration

### Checkout (`src/app/api/stripe/checkout/route.ts`)

```typescript
import 'server-only';
import { NextRequest, NextResponse } from 'next/server';
import { verifySession } from '@/lib/session-verifier';
import Stripe            from 'stripe';
import { serverEnv }     from '@/lib/env';

const stripe = new Stripe(serverEnv.STRIPE_SECRET_KEY);

export async function POST(req: NextRequest) {
  const claims = await verifySession();
  if (!claims) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 });

  const { planId } = await req.json();
  const siteUrl    = process.env.NEXT_PUBLIC_SITE_URL!;

  const session = await stripe.checkout.sessions.create({
    mode:           'subscription',
    line_items:     [{ price: planId, quantity: 1 }],
    customer_email: claims.email,
    metadata:       { uid: claims.uid },
    success_url:    `${siteUrl}/dashboard?checkout=success`,
    cancel_url:     `${siteUrl}/subscriptions`,
  });

  return NextResponse.json({ url: session.url });
}
```

### Webhook (`src/app/api/stripe/webhook/route.ts`)

```typescript
import 'server-only';
import { NextRequest, NextResponse } from 'next/server';
import Stripe        from 'stripe';
import { adminDb }   from '@/lib/firebase-admin';
import { serverEnv } from '@/lib/env';

const stripe = new Stripe(serverEnv.STRIPE_SECRET_KEY);

export async function POST(req: NextRequest) {
  const body = await req.text(); // Must be raw body — do NOT use req.json()
  const sig  = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, serverEnv.STRIPE_WEBHOOK_SECRET);
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  const db = adminDb();

  if (event.type === 'checkout.session.completed') {
    const s   = event.data.object as Stripe.Checkout.Session;
    const uid = s.metadata?.uid;
    if (uid) {
      await db.collection('users').doc(uid).update({
        tier:                 resolveTier(s.metadata?.planId ?? ''),
        stripeCustomerId:     s.customer,
        stripeSubscriptionId: s.subscription,
      });
    }
  }

  if (event.type === 'customer.subscription.deleted') {
    const sub = event.data.object as Stripe.Subscription;
    const uid = sub.metadata?.uid;
    if (uid) await db.collection('users').doc(uid).update({ tier: 'free' });
  }

  return NextResponse.json({ received: true });
}

function resolveTier(planId: string): 'free' | 'pro' | 'dev' {
  if (planId === process.env.STRIPE_PRO_PLAN_ID) return 'pro';
  if (planId === process.env.STRIPE_DEV_PLAN_ID) return 'dev';
  return 'free';
}
```

---

## 9. LLM Playground — Streaming Engine

### 9.1 Types (`src/lib/playground/types.ts`)

```typescript
export type ModelTier = 'free' | 'pro' | 'dev';

export interface ModelEntry {
  id:                string;
  label:             string;
  provider:          'openai-compatible' | 'google' | 'local';
  apiModelId:        string;
  tier:              ModelTier;
  contextWindow:     number;
  supportsVision:    boolean;
  supportsStreaming: boolean;
  badge?:            string;
}

export interface ChatMessage {
  role:    'user' | 'assistant' | 'system';
  content: string;
}

export interface StreamChunk {
  type:     'delta' | 'done' | 'error' | 'metrics';
  delta?:   string;
  error?:   string;
  metrics?: {
    inputTokens:  number;
    outputTokens: number;
    ttft:         number;  // ms to first token
    totalMs:      number;
  };
}
```

### 9.2 Model registry (`src/lib/playground/providers/index.ts`)

```typescript
import type { ModelEntry } from '../types';

export const MODEL_REGISTRY: ModelEntry[] = [
  {
    id: 'gpt-4o', label: 'GPT-4o',
    provider: 'openai-compatible', apiModelId: 'gpt-4o',
    tier: 'pro', contextWindow: 128000,
    supportsVision: true, supportsStreaming: true,
  },
  {
    id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash',
    provider: 'openai-compatible', apiModelId: 'gemini-2.0-flash',
    tier: 'free', contextWindow: 1000000,
    supportsVision: true, supportsStreaming: true, badge: 'Fast',
  },
  {
    id: 'ollama-llama3', label: 'Llama 3 (Local)',
    provider: 'local', apiModelId: 'llama3',
    tier: 'free', contextWindow: 8192,
    supportsVision: false, supportsStreaming: true, badge: 'Local',
  },
  // Add more models here
];

export const getModel = (id: string) => MODEL_REGISTRY.find(m => m.id === id);
```

### 9.3 OpenAI-compatible adapter

```typescript
// src/lib/playground/providers/openai-compatible.ts
import 'server-only';
import { StreamChunk } from '../types';

export async function* streamOpenAICompatible(
  apiKey:    string,
  baseURL:   string,
  model:     string,
  messages:  { role: string; content: string }[],
  maxTokens = 4096,
): AsyncGenerator<StreamChunk> {
  const startMs = Date.now();
  let ttft = 0, inputTokens = 0, outputTokens = 0;

  const resp = await fetch(`${baseURL}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({
      model, messages, stream: true, max_tokens: maxTokens,
      stream_options: { include_usage: true },
    }),
  });

  if (!resp.ok || !resp.body) {
    yield { type: 'error', error: `API error ${resp.status}` };
    return;
  }

  const reader  = resp.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const text = decoder.decode(value);
    for (const line of text.split('\n')) {
      const trimmed = line.replace(/^data: /, '').trim();
      if (!trimmed || trimmed === '[DONE]') continue;
      try {
        const json  = JSON.parse(trimmed);
        const delta = json.choices?.[0]?.delta?.content;
        if (delta) {
          if (!ttft) ttft = Date.now() - startMs;
          yield { type: 'delta', delta };
          outputTokens++;
        }
        if (json.usage) {
          inputTokens  = json.usage.prompt_tokens     ?? inputTokens;
          outputTokens = json.usage.completion_tokens ?? outputTokens;
        }
      } catch { /* skip malformed SSE lines */ }
    }
  }

  yield {
    type: 'metrics',
    metrics: { inputTokens, outputTokens, ttft, totalMs: Date.now() - startMs },
  };
}
```

### 9.4 SSE route (`src/app/api/playground/stream/[modelId]/route.ts`)

```typescript
import 'server-only';
import { NextRequest }                from 'next/server';
import { verifySession }              from '@/lib/session-verifier';
import { getModel }                   from '@/lib/playground/providers';
import { streamOpenAICompatible }     from '@/lib/playground/providers/openai-compatible';
import { serverEnv }                  from '@/lib/env';
import { encodeSSE }                  from '@/lib/playground/sse';

export const runtime     = 'nodejs';
export const maxDuration = 120;

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ modelId: string }> },
) {
  const { modelId } = await params;   // Must await in Next.js 16
  const claims = await verifySession();
  if (!claims) return new Response('Unauthenticated', { status: 401 });

  const model = getModel(modelId);
  if (!model) return new Response('Unknown model', { status: 404 });

  // TODO: enforce tier gate
  // const userTier = await getUserTier(claims.uid);
  // if (!isTierAllowed(userTier, model.tier)) return tierError();

  const { messages, maxTokens } = await req.json();

  const stream = new ReadableStream({
    async start(controller) {
      try {
        const isLocal = model.provider === 'local';
        const gen = streamOpenAICompatible(
          isLocal ? 'ollama' : serverEnv.LLM_GATEWAY_API_KEY,
          isLocal ? serverEnv.OLLAMA_BASE_URL + '/v1' : serverEnv.LLM_GATEWAY_BASE_URL,
          model.apiModelId,
          messages,
          maxTokens,
        );
        for await (const chunk of gen) {
          controller.enqueue(encodeSSE(chunk));
        }
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection:      'keep-alive',
    },
  });
}
```

### 9.5 SSE helpers (`src/lib/playground/sse.ts`)

```typescript
import type { StreamChunk } from './types';

const encoder = new TextEncoder();
export const encodeSSE = (chunk: StreamChunk) =>
  encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`);

// Client-side reader
export async function* readSSE(response: Response): AsyncGenerator<StreamChunk> {
  const reader  = response.body!.getReader();
  const decoder = new TextDecoder();
  let buffer    = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) {
      const data = line.replace(/^data: /, '').trim();
      if (data) { try { yield JSON.parse(data); } catch { /* skip */ } }
    }
  }
}
```

---

## 12. Subscription Tier System

The tier system controls **credit allowance**, not model access. All authenticated
users — free, pro, or developer — can reach every model in the registry. Guests
(unauthenticated) get a separate rolling request pool, not credits.

```typescript
// src/lib/playground/tier-config.ts
export type UserTier = 'free' | 'pro' | 'developer';

/** USD value of one credit. Anchor all pricing math to this. */
export const USD_PER_CREDIT = 0.0008 as const;

export interface TierConfig {
  tier: UserTier;
  label: string;
  monthlyPriceUsd: number;
  creditsLimit: number;
  /** Env var name holding the Stripe Price ID. null for free tier. */
  stripePriceIdEnvVar: 'STRIPE_PRO_PLAN_ID' | 'STRIPE_DEV_PLAN_ID' | null;
}

export const TIER_MATRIX: Readonly<Record<UserTier, TierConfig>> = {
  free:      { tier: 'free',      label: 'Free',      monthlyPriceUsd: 0,  creditsLimit: 1_000,  stripePriceIdEnvVar: null },
  pro:       { tier: 'pro',       label: 'Pro',       monthlyPriceUsd: 25, creditsLimit: 10_000, stripePriceIdEnvVar: 'STRIPE_PRO_PLAN_ID' },
  developer: { tier: 'developer', label: 'Developer', monthlyPriceUsd: 45, creditsLimit: 25_000, stripePriceIdEnvVar: 'STRIPE_DEV_PLAN_ID' },
} as const;

/** Guest rolling request pool (unauthenticated users). */
export const GUEST_REQUEST_LIMIT = 10;     // max weighted requests per 72h
export const GUEST_IMAGE_LIMIT = 5;        // max image generations per 72h
export const GUEST_WINDOW_MS = 72 * 60 * 60 * 1000;
export const GUEST_REQUEST_CHARS_PER_POINT = 1000;

export function guestRequestCost(prompt: string): number {
  const chars = typeof prompt === 'string' ? prompt.length : 0;
  return Math.max(1, Math.ceil(chars / GUEST_REQUEST_CHARS_PER_POINT));
}
```

### Credit cost formula

Credit cost per run (implemented in `lib/playground/credit-engine.ts`):

```
Cost = (cachedInputTokens / 1000 × cachedInputMultiplier)
     + (freshInputTokens  / 1000 × inputMultiplier)
     + (outputTokens      / 1000 × outputMultiplier)
```

Local models set all multipliers to 0, so local runs never deduct credits.
Credits are atomically deducted via `FieldValue.increment(-amount)` inside a
Firestore transaction — the post-write value is read to enforce the
insufficient-balance invariant.

---

## 13. Dashboard Page

```tsx
// src/app/dashboard/page.tsx
import { verifySession } from '@/lib/session-verifier';
import { redirect }      from 'next/navigation';

export default async function DashboardPage() {
  const claims = await verifySession();
  if (!claims) redirect('/login');

  // Fetch user doc from Firestore server-side here

  return (
    <main>
      {/* Usage stats, quick links, account settings */}
    </main>
  );
}
```

---

## 14. Playground Page — State Shape

The playground is a **Client Component** (`'use client'`):

```tsx
interface Column {
  id:       string;
  modelId:  string;
  messages: ChatMessage[];
  status:   'idle' | 'streaming' | 'done' | 'error';
  metrics?: StreamChunk['metrics'];
}

const [columns, setColumns] = useState<Column[]>([/* one initial column */]);
const [prompt,  setPrompt]  = useState('');
```

**Send flow:**
1. Fan out to all columns with `Promise.all`.
2. Each column `POST /api/playground/stream/{modelId}` and reads SSE via `readSSE()`.
3. On each `delta`, update the matching column's last message.
4. On `metrics`, store timing for the column header display.

---

## 15. Admin Panel

Gate by Firebase custom claim:

```typescript
const claims = await verifySession();
if (!claims?.admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
```

Set once with Admin SDK:
```typescript
await adminAuth().setCustomUserClaims(uid, { admin: true });
```

---

## 16. Deployment

> **Next.js + Firebase App Hosting reference** — if you are using a different
> framework or host (Vercel, Fly.io, Railway, Cloud Run), follow that platform's
> deployment guide. The environment variable list in Section 4 is what every
> deployment target needs, regardless of platform.

### Firebase App Hosting (`apphosting.yaml`)

```yaml
runConfig:
  cpu:          1
  memoryMiB:    512
  minInstances: 0
  maxInstances: 3
  concurrency:  80

env:
  - variable: NEXT_PUBLIC_FIREBASE_API_KEY
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_FIREBASE_PROJECT_ID
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_FIREBASE_APP_ID
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_SITE_URL
    availability: [BUILD, RUNTIME]
  - variable: NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
    availability: [BUILD, RUNTIME]
  - variable: GOOGLE_APPLICATION_CREDENTIALS_JSON
    secret: GOOGLE_APPLICATION_CREDENTIALS_JSON
  - variable: STRIPE_SECRET_KEY
    secret: STRIPE_SECRET_KEY
  - variable: STRIPE_WEBHOOK_SECRET
    secret: STRIPE_WEBHOOK_SECRET
  - variable: LLM_GATEWAY_API_KEY
    secret: LLM_GATEWAY_API_KEY
  - variable: GOOGLE_AI_API_KEY
    secret: GOOGLE_AI_API_KEY
```

Deploy:
```bash
firebase login
firebase init apphosting
firebase apphosting:secrets:set STRIPE_SECRET_KEY
firebase apphosting:secrets:set LLM_GATEWAY_API_KEY
git push origin main  # auto-deploys on push
```

---

## 17. Firestore Security Rules

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }

    match /usage/{uid}/{rest=**} {
      allow read:  if request.auth != null && request.auth.uid == uid;
      allow write: if false; // Admin SDK only
    }

    match /{document=**} {
      allow read, write: if false; // Default deny
    }
  }
}
```

---

## 18. Rate Limiting

Use two separate mechanisms: a **rate limiter** (requests per window) and a
**concurrency limiter** (simultaneous in-flight calls). Both are in-memory
with automatic cleanup.

```typescript
// src/lib/rate-limit.ts
const tracker = new Map<string, { count: number; resetTime: number }>();

function cleanupExpiredTracker(now: number): void {
  if (tracker.size <= 500) return;
  for (const [key, record] of tracker.entries()) {
    if (now > record.resetTime) tracker.delete(key);
  }
}

/**
 * Returns true if the identifier has EXCEEDED the limit (i.e., should 429).
 * Note: inverted from the common "isAllowed" pattern.
 */
export function isRateLimited(identifier: string, limit = 10, windowMs = 60_000): boolean {
  const now = Date.now();
  cleanupExpiredTracker(now);
  const record = tracker.get(identifier);
  if (!record || now > record.resetTime) {
    tracker.set(identifier, { count: 1, resetTime: now + windowMs });
    return false;
  }
  record.count += 1;
  return record.count > limit;
}

// ─── Concurrency limiter ──────────────────────────────────────────────────
const inFlight = new Map<string, number>();

export function tryAcquireConcurrency(key: string, max: number): boolean {
  const current = inFlight.get(key) ?? 0;
  if (current >= max) return false;
  inFlight.set(key, current + 1);
  return true;
}

export function releaseConcurrency(key: string): void {
  const current = inFlight.get(key) ?? 0;
  if (current <= 1) inFlight.delete(key);
  else inFlight.set(key, current - 1);
}

/** Extract client IP from trusted headers (Cloudflare → nginx → forwarded). */
export function getTrustedClientIp(req: Request): string {
  return req.headers.get('cf-connecting-ip')?.trim()
    ?? req.headers.get('x-real-ip')?.trim()
    ?? req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
    ?? '127.0.0.1';
}
```

Usage in routes:

```typescript
if (isRateLimited(`stream:${uid}`, 30, 60_000))
  return new Response('Rate limited', { status: 429 });
if (!tryAcquireConcurrency(uid, 5))
  return new Response('Too many concurrent streams', { status: 429 });
try {
  // ... stream ...
} finally {
  releaseConcurrency(uid);
}
```

### Per-route defaults (define as named constants, not magic numbers)

```typescript
export const PLAYGROUND_STREAM_RATE_LIMIT     = 30; // per minute per uid
export const PLAYGROUND_STREAM_MAX_CONCURRENT = 5;  // simultaneous streams
export const PLAYGROUND_GUEST_RATE_LIMIT      = 20; // per minute per IP
export const STUDIO_IMAGE_RATE_LIMIT          = 5;
export const STUDIO_IMAGE_MAX_CONCURRENT      = 2;
export const STUDIO_VIDEO_RATE_LIMIT          = 2;
export const STUDIO_VIDEO_MAX_CONCURRENT      = 1;
```

---

## 19. SEO Checklist

Every page:
```tsx
export const metadata: Metadata = {
  title:       'Page Title | App Name',
  description: 'Compelling 150-char description.',
  alternates:  { canonical: '/page-path' },
  openGraph: {
    title: '...', description: '...',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
};
```

Also:
- `src/app/robots.ts` — disallow `/admin`, `/api`
- `src/app/sitemap.ts` — all public routes with `lastModified`

---

## 20. `next.config.ts` Essentials

```typescript
import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  typescript:             { ignoreBuildErrors: false },
  turbopack:              { root: process.cwd() },
  httpAgentOptions:       { keepAlive: false },
  serverExternalPackages: ['firebase-admin'],
  transpilePackages:      ['firebase-admin'],
  images: {
    unoptimized: true,
    remotePatterns: [
      { protocol: 'https', hostname: 'images.unsplash.com', pathname: '/**' },
    ],
  },
  async headers() {
    return [{
      source: '/(.*)',
      headers: [
        { key: 'X-Frame-Options',          value: 'DENY' },
        { key: 'X-Content-Type-Options',   value: 'nosniff' },
        { key: 'Referrer-Policy',          value: 'strict-origin-when-cross-origin' },
        { key: 'Strict-Transport-Security',value: 'max-age=63072000; includeSubDomains; preload' },
        { key: 'Permissions-Policy',       value: 'camera=(), microphone=(self), geolocation=()' },
      ],
    }];
  },
};

export default nextConfig;
```

---

## 21. Build Order

Follow this sequence — each step's primitives are used by the next:

1. Scaffold + install deps + `globals.css` color tokens
2. Firebase client config + Admin SDK + `FirebaseClientProvider` + session route
3. Auth pages + auth-guard + middleware redirects
4. Firestore user doc creation on first login + security rules
5. Landing page — hero, features, pricing, footer
6. Subscriptions — Stripe checkout + webhook + tier updates
7. Dashboard — user stats, subscription status
8. Playground — model registry + SSE stream route + column UI + prompt bar
9. Admin panel — user list, usage overview
10. SEO + deployment — metadata, robots, sitemap, `apphosting.yaml`, secrets

---

## 22. Common Pitfalls

| Pitfall | Fix |
|---------|-----|
| `firebase-admin` crashes ERR_REQUIRE_ESM | Add to `transpilePackages` in `next.config.ts` |
| Session verifier fails in Edge runtime | The Edge runtime cannot use `firebase-admin`. Implement RS256 JWT verification via Web Crypto + Firebase JWKS (`/metadata/jwk/firebase-adminsdk`). Cache JWKS with 1h TTL. |
| Session cookie not set on OAuth popup | Call `/api/session POST` inside `onAuthStateChanged`, not after `signInWithPopup` |
| SSE stream closes immediately | Set `export const runtime = 'nodejs'` — edge runtime doesn't support long-lived streams |
| Stripe webhook 400 "No signatures found" | Use `req.text()` (raw body), not `req.json()`, before `constructEvent` |
| TailwindCSS v4 `@config` resolution failure | Move all config into `globals.css` `@theme` block; delete `tailwind.config.ts` |
| `process.env` undefined in client bundle | Only use `NEXT_PUBLIC_*` client-side; server vars via `serverEnv.*` |
| Admin SDK initializes multiple times in dev | Singleton: `getApps().find(a => a.name === 'admin')` |
| TypeScript error on `params` in route handlers | Always `await params` — Next.js 16 makes route params a `Promise` |
| Missing CORS on SSE endpoint | SSE is same-origin by default; add `Access-Control-Allow-Origin` if cross-origin |
| Framer Motion hydration mismatch | Wrap in `<LazyMotion features={domAnimation}>` or use `suppressHydrationWarning` |

---

## 23. QA & Security Audit

Run this checklist **after every feature is built and before declaring the site done**. Do not skip any item. Report each result inline (✅ pass / ❌ fail + fix applied).

---

### 23.1 Functional QA

| Area | Check |
|------|-------|
| Auth | Sign-up with email creates Firestore `/users/{uid}` doc |
| Auth | Google OAuth popup sets session cookie and redirects to `/dashboard` |
| Auth | Unauthenticated visit to `/dashboard` redirects to `/login` |
| Auth | Authenticated visit to `/login` redirects to `/dashboard` |
| Auth | Sign-out clears `__session` cookie and redirects to `/` |
| Onboarding | First login redirects to `/onboarding`; completion sets `onboardingComplete: true` |
| Subscriptions | Stripe Checkout session creates with correct `planId` and `customer_email` |
| Subscriptions | `checkout.session.completed` webhook updates Firestore `tier` field |
| Subscriptions | `customer.subscription.deleted` webhook resets `tier` to `free` |
| Playground | SSE stream delivers `delta` chunks and closes with a `metrics` chunk |
| Playground | Free-tier user cannot access a `pro`-tier model (returns 403) |
| Playground | Rate limit returns 429 after exceeding the configured request window |
| Admin | Non-admin user gets 403 on `/api/admin/*` routes |
| Admin | Admin custom claim set via Admin SDK grants access |
| UI | All pages render without console errors in both light and dark mode |
| UI | Hero placeholder is visible; AI has asked the user about the hero asset |
| UI | All CTAs, nav links, and footer links resolve to valid routes |
| Responsive | Pages are usable at 375 px (mobile), 768 px (tablet), 1280 px (desktop) |

---

### 23.2 Security Audit

#### Secrets & Environment

- [ ] No secret keys (`STRIPE_SECRET_KEY`, `LLM_GATEWAY_API_KEY`, `GOOGLE_APPLICATION_CREDENTIALS_JSON`, etc.) appear anywhere in client-side bundles or `NEXT_PUBLIC_*` variables
- [ ] `.env.local` is in `.gitignore` — confirm with `git check-ignore -v .env.local`
- [ ] `.env.example` contains only empty placeholder values — no real credentials
- [ ] All server secrets are accessed exclusively via `serverEnv.*` (never `process.env` directly in route handlers)
- [ ] Firebase App Hosting secrets are set via `firebase apphosting:secrets:set`, not hardcoded in `apphosting.yaml`

Run:
```bash
# Scan for accidentally committed secrets
git log --all --full-history -- .env.local
npx secretlint "**/*" --secretlintrc '{"rules":[{"id":"@secretlint/secretlint-rule-preset-recommend"}]}'
```

#### HTTP Security Headers

Verify all headers are present on every page response:

```bash
curl -sI https://your-domain.com | grep -iE "content-security-policy|x-frame-options|x-content-type-options|strict-transport-security|referrer-policy|permissions-policy"
```

Expected:
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`
- `Content-Security-Policy` present and does **not** contain `unsafe-eval`

#### Firestore Security Rules

- [ ] `/users/{uid}` — only the owning user can read/write
- [ ] `/usage/{uid}/**` — read only by owning user; writes blocked (Admin SDK only)
- [ ] Default deny `/{document=**}` rule is in place
- [ ] Rules are deployed: `firebase deploy --only firestore:rules`
- [ ] Validate rules using the Firebase Emulator or Rules Playground with both authenticated and unauthenticated requests

#### Auth

- [ ] Session cookie is `httpOnly: true`, `sameSite: 'lax'`, `secure: true` in production
- [ ] `verifySessionCookie(cookie, true)` — `checkRevoked: true` is set so revoked tokens are rejected
- [ ] Admin routes check `claims.admin === true`, not just `claims !== null`
- [ ] Password reset and email verification flows do not expose the user's UID in the URL

#### Stripe

- [ ] Webhook signature is verified with `stripe.webhooks.constructEvent()` using raw `req.text()` body
- [ ] Webhook secret is read from `serverEnv.STRIPE_WEBHOOK_SECRET`, not hardcoded
- [ ] `planId` from webhook metadata is validated against known plan IDs before writing to Firestore
- [ ] Stripe publishable key (`NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`) is the only Stripe value in the client bundle

#### Rate Limiting & Abuse

- [ ] All LLM stream endpoints are rate-limited per `uid`
- [ ] Unauthenticated requests to stream endpoints return 401 before hitting the LLM provider
- [ ] Tier-gate check runs before the stream starts, not after

#### Dependency Audit

```bash
npm audit --audit-level=high
```

- [ ] No high or critical vulnerabilities. If any exist, update the dependency or document a mitigation.

---

### 23.3 Lighthouse / Performance Baseline

Run against the production URL (or `npm run build && npx serve out`):

```bash
npx lighthouse https://your-domain.com --output=json --output-path=./lighthouse-report.json --chrome-flags="--headless"
```

Minimum passing scores:

| Category | Target |
|----------|--------|
| Performance | ≥ 80 |
| Accessibility | ≥ 90 |
| Best Practices | ≥ 90 |
| SEO | ≥ 95 |

Fix any failures before sign-off.

---

### 23.4 Sign-Off Gate

**Do not deploy or mark the build complete until all of the following are true:**

- [ ] All 23.1 functional QA items pass
- [ ] All 23.2 security checklist items are checked
- [ ] Lighthouse scores meet the 23.3 targets
- [ ] `npm audit` returns zero high/critical issues
- [ ] Hero section has either a real asset or a confirmed AI-generated placeholder
- [ ] `.env.local` is not tracked by git

If any item fails, fix it and re-run that section before proceeding.

---

## Appendix A — Next.js + Firebase Full Install

Full scaffold and dependency install for the Next.js 16 reference implementation:

```bash
npx create-next-app@latest ./ \
  --typescript --tailwind --eslint --app --src-dir \
  --import-alias "@/*" --no-turbopack

npm install \
  firebase firebase-admin \
  stripe @stripe/stripe-js \
  framer-motion lucide-react \
  clsx tailwind-merge class-variance-authority \
  @radix-ui/react-dialog @radix-ui/react-toast \
  @radix-ui/react-scroll-area @radix-ui/react-slot \
  @radix-ui/react-accordion \
  next-themes server-only nodemailer

npm install -D @types/nodemailer tsx dotenv-cli
```

For a fully automated version of this setup (secrets provisioning, deployment,
analytics, Sentry, white-label config, post-build QA report), use the
**`ai-saas-website-pro`** skill.
