---
name: stripe-subscription-engine
title: "Stripe Subscription Engine: Ship Production SaaS Billing in a Day"
summary: "Scaffold a complete, production-ready Stripe subscription system  Checkout, customer portal, bulletproof webhooks, plans, seats, proration, and dunning  wired to your database."
version: 1.0.0
author: pubspro.toolkit
license: commercial
tags:
  - stripe
  - billing
  - subscriptions
  - saas
  - payments
  - webhooks
  - nextjs
compatibility: "Works with Next.js, Remix, SvelteKit, Express, and most Node/TypeScript backends. Requires a Stripe account and a SQL database (Postgres recommended). Best with Claude Code 1.2+ and an agent with filesystem + terminal access."
permissions:
  file_scopes:
    - "src/**"
    - "app/**"
    - "lib/**"
    - "prisma/**"
_agensi: "d88bbcda-f210-4056-bf65-a0ad27aebd1d"
---

# Stripe Subscription Engine

Billing is the part of your SaaS that has to be perfect  and it is the part most likely to be quietly broken. **Stripe Subscription Engine** turns your AI agent into a senior payments engineer that scaffolds a complete, production-grade subscription system end to end: Checkout, the customer portal, idempotent webhooks, plan and seat management, proration, and dunning  all wired to your database with the edge cases already handled.

## The Problem

Every SaaS needs subscription billing, and almost every hand-rolled implementation is subtly wrong. The happy path  a customer subscribes  is easy. The money-losing parts are everything else: a webhook that fires twice and double-charges, a `checkout.session.completed` you trusted before the invoice was paid, a downgrade that forgets to prorate, a failed renewal that never triggers a dunning email so the customer silently churns, a subscription whose state drifts out of sync with your database after a Stripe-side change. These bugs do not crash  they leak revenue and erode trust, and you usually find them in a support ticket.

## What It Does

Stripe Subscription Engine scaffolds the entire billing layer with production hardening built in:

1. **Checkout & Portal**  Generates the Checkout Session flow for new subscriptions and wires up the Stripe Customer Portal so users can upgrade, downgrade, update cards, and cancel without you building any UI.
2. **Bulletproof Webhooks**  Builds a signature-verified, idempotent webhook handler that processes every subscription lifecycle event exactly once, with replay safety and an event log.
3. **Plans, Seats & Proration**  Implements tiered plans, per-seat billing, mid-cycle upgrades/downgrades, and correct proration so customers are always charged the right amount.
4. **Dunning & Recovery**  Handles failed payments with retry logic, customer notifications, and a grace period so a declined card does not become silent churn.
5. **Source-of-Truth Sync**  Generates the database schema and reconciliation logic that keeps your local subscription state perfectly in sync with Stripe, even after out-of-band changes.

## Why Use This Skill

Billing is the highest-stakes, lowest-tolerance code in your product: a bug here charges real customers real money. This skill encodes the patterns payments teams learn the hard way  idempotency keys, webhook-driven state, never trusting the client, reconciliation over assumption  into a complete scaffold your agent generates in minutes instead of the week it takes to get right by hand. It pays for itself the first time it prevents a single double-charge or a month of silent churn.

## Supported Stacks

- **Frameworks:** Next.js (App Router, default), Remix, SvelteKit, Express, NestJS, and most Node/TypeScript backends.
- **Database/ORM:** Postgres with Prisma (default), Drizzle, or raw SQL; adaptable to MySQL.
- **Payments:** Stripe Billing (Checkout, Customer Portal, Webhooks, the Subscriptions API).

## Sample Input

> Set up subscription billing for my Next.js SaaS. I have three plans (Starter, Pro, Team) with Team being per-seat. Use Stripe and our existing Postgres + Prisma setup. I need upgrades to prorate and failed payments to retry before cancelling.

## Sample Output

> I've scaffolded the full billing layer:
> - Prisma models: Customer, Subscription, Price, and a WebhookEvent log for idempotency.
> - /api/checkout route that creates a Checkout Session for Starter/Pro/Team (Team collects seat quantity).
> - /api/webhooks/stripe with signature verification and an exactly-once handler for created/updated/deleted, invoice.paid, and invoice.payment_failed.
> - Customer Portal session route for self-serve upgrades, downgrades (prorated), and cancellations.
> - Dunning: 3 smart retries over 7 days with email hooks, then a grace period before downgrade.
> Next step: add your Stripe price IDs to .env (placeholders generated) and run the included webhook test script against the Stripe CLI.

## Use Cases

- Launch billing for a new SaaS in a day instead of a week, with the edge cases already covered.
- Replace a fragile hand-rolled Stripe integration with a hardened, idempotent one.
- Add per-seat or tiered plans and correct proration to an existing product.
- Stop revenue leakage from failed-payment churn with built-in dunning.

## Known Limitations

- You bring your own Stripe account and set your product/price IDs; the skill generates the integration and placeholders, not your Stripe catalog.
- Tax (Stripe Tax) and complex usage-based metered billing are scaffolded as optional extension points rather than fully configured, since they depend on your jurisdiction and metering model.
- The skill never handles live card data directly  all card entry happens in Stripe-hosted Checkout and Portal, by design.

## Frequently Asked Questions

**Does this store or touch customer card numbers?**
No. All card entry happens in Stripe-hosted Checkout and the Customer Portal, so raw card data never touches your servers. The skill only handles tokens, IDs, and subscription state.

**What makes the webhooks 'bulletproof'?**
They are signature-verified and idempotent: every event is logged and processed exactly once, so a duplicate or replayed webhook can never double-charge or corrupt your subscription state.

**Can it handle per-seat and tiered pricing with proration?**
Yes. It scaffolds tiered plans, per-seat quantities, and mid-cycle upgrades/downgrades with Stripe's proration, so customers are always billed the correct amount.

**Which stack does it support?**
Next.js by default, plus Remix, SvelteKit, Express, and NestJS, with Postgres/Prisma as the default data layer and Drizzle or raw SQL as alternatives.